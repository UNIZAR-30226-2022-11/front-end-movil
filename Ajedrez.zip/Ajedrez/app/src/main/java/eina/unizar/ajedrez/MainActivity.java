package eina.unizar.ajedrez;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import javax.security.auth.callback.Callback;

public class MainActivity extends AppCompatActivity {
    ChessBoard myCanvas;
    LinearLayout linlay;
    ImageView imgView;
    Paint p;
    int width,height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myCanvas = new ChessBoard(this);
        setContentView(R.layout.activity_main);

        LinearLayout layout = (LinearLayout) findViewById(R.id.layout);
        layout.addView(myCanvas);

        //setContentView(R.layout.activity_main);


       /* SurfaceView surface = (SurfaceView) findViewById(R.id.surface);
        surface.getHolder().addCallback(new Callback() {
        @Override
            public void surfaceCreated(SurfaceHolder holder) {
                // Do some drawing when surface is ready
                Canvas canvas = holder.lockCanvas();
                canvas.drawColor(Color.RED);
                holder.unlockCanvasAndPost(canvas);
            }


            public void surfaceDestroyed(SurfaceHolder holder) {
            }


            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }
        });*/

       /* linlay=new LinearLayout(this);
        imgView =  new ImageView(this);
        imgView.setLayoutParams(new LinearLayout.LayoutParams(width,height));
        linlay.addView(imgView);

        linlay.setOrientation(LinearLayout.VERTICAL);
        linlay.setGravity(Gravity.CENTER_HORIZONTAL);*/

        //myCanvas = new ChessBoard(this);
        //setContentView(myCanvas);

        //

    }
}