package eina.unizar.ajedrez;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class UserRegistration extends AppCompatActivity {
    private EditText mUsername;
    private EditText mUserPassword;
    private Long mRowId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // mDbHelper = new NotesDbAdapter(this);
        //mDbHelper.open();
       // setContentView(R.layout.note_edit);
       // setTitle(R.string.edit_note);

        mUsername = (EditText) findViewById(R.id.username);
        mUserPassword = (EditText) findViewById(R.id.userPassword);

        Button confirmButton = (Button) findViewById(R.id.submit);

        confirmButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }

        });
        /*mRowId = (savedInstanceState == null) ? null:
                (Long) savedInstanceState.getSerializable(NotesDbAdapter.KEY_ROWID);
        if (mRowId == null) {
            Bundle extras = getIntent().getExtras();
            mRowId = (extras != null) ?
                    extras.getLong(NotesDbAdapter.KEY_ROWID) : null;
        }*/


    }
}
