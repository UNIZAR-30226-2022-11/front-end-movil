package eina.unizar.ajedrez;

/*******************************/
/*3 opciones:
    - Crear 64 botonoes que formen un tablero
    - Dibujar el tablero simplemente con java y sobre el colocar las piezas
    - Dibujar el tablero usando xml y sobre el colocar las piezas
*/

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;

/*******************************/
public class ChessBoard extends View {
    Paint p,q;
    Rect Rec;
    int NUM_FILCOL = 8;
    int x0=65;
    int squareSize = 80;
    int x1= x0 +squareSize;
    //int xEnd= 160;
    int y0 = 185;

    public ChessBoard(Context context){
        super(context);
        p = new Paint();
        q = new Paint();
        Rec = new Rect();
    }
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawBoard(canvas);
    }

    protected void drawBoard(Canvas canvas){
        p.setStrokeWidth(3);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.DKGRAY);

        q.setStrokeWidth(3);
        q.setStyle(Paint.Style.FILL);
        q.setColor(Color.LTGRAY);
    for(int j = 0; j < NUM_FILCOL/2;j++) {
        for (int i = 0; i < 4; i++) {
            canvas.drawRect(x0 + (2*squareSize * i), y0+(2*squareSize*j), x1 + (2*squareSize * i), y0 + squareSize +(2*squareSize*j), p);
            canvas.drawRect(x1 + (2*squareSize * i), y0+(2*squareSize*j), x1 + squareSize + (2*squareSize * i), y0 + squareSize+(2*squareSize*j), q);
            canvas.drawRect(x1 + (2*squareSize * i), y0+(squareSize*(2*j+1)), x1 + squareSize + (2*squareSize * i), y0 + squareSize+(squareSize*(2*j+1)), p);
            canvas.drawRect(x0 + (2*squareSize * i), y0+(squareSize*(2*j+1)), x1 + (2*squareSize * i), y0 + squareSize+(squareSize*(2*j+1)), q);
        }
    }
    }
}


